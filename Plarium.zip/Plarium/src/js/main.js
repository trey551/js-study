require.config({
    baseUrl: 'js',
    paths: {
        'jQuery': '../../bower/jquery/dist/jquery',
        'domReady': '../../bower/requirejs-domready/domReady',
        'plaxmove': 'lib/plaxmove',
        'async': '../../bower/async/lib/async'
    },
    shim: {
        'jQuery': {
            exports: '$'
        },
        'plaxmove': {
            'deps': ['jQuery']
        },
        'animo': {
            'deps': ['jQuery']
        }
    }
});

require([
    'jQuery',
    'async',
    'domReady',
    'utils',
    'modules/plaxmove',
    'modules/animations',
    'modules/form'
], function ($, async, plaxmove, domReady, utils, animations) {
    animations.animateEquip();

    async.series([
        animations.animateCharacterFrame,
        animations.animateCharacter,
        animations.animateButtons,
        animations.animateRows,
        animations.animateFacebookButton,
        animations.animateCheckboxes,
        animations.animateBtnPlay
    ]);

    initCharSwitcher();
});

function initCharSwitcher() {
    $('.btns').each(function (i) {
        if (!localStorage) return;

        var storage = localStorage.getItem('char');
        if (storage) {
            $('.btns button').removeClass('active');
            $('div.char').removeClass('selected');
            $(this)
                .find('button')
                .eq(storage)
                .addClass('active')
                .siblings()
                .removeClass('active');

            $('div.char_holder')
                .find('div.char')
                .fadeOut()
                .eq(storage)
                .addClass('selected')
                .fadeIn(300);
        }
    })
    
    $('.btns').delegate('button:not(.active)', 'click', function () {
        $('.btns button').removeClass('active');
        $('div.char').removeClass('selected');
        $(this)
            .addClass('current')
            .siblings()
            .removeClass('current');

        $('div.char_holder')
            .find('div.char')
            .eq($(this).index())
            .addClass('selected')
            .fadeIn(300)
            .siblings('div.char')
            .hide();
        localStorage.setItem('char', $(this).index());
    });
}
