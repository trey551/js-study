define([
    'jQuery'
], function ($) {
    return {
        animateCharacterFrame: function (cb) {
            $('.char_frame')
                .css({opacity: '1'})
                .addClass('animated frameAnimationScale')
                .callback(cb);
        },

        animateCharacter: function (cb) {
            $('div.char')
                .addClass('animated fadeIn')
                .callback(cb);
        },

        animateButtons: function (cb) {
            $('#form .icon').each(function (i) {
                $(this)
                    .css({
                        display: 'block',
                        'animationDelay': i * 0.05 + 's'
                    })
                    .addClass('animated zoomIn')
            }).last().callback(cb);
        },

        animateRows: function (cb) {
            $('#form .row').each(function (i) {
                $(this)
                    .css({
                        'transitionDelay': i * 0.05 + 's'
                    })
                    .addClass('full-width');
            }).last().callback(cb);
        },

        animateFacebookButton: function (cb) {
            $('div.facebook button')
                .addClass('animated fadeIn')
                .callback(cb);
        },

        animateCheckboxes: function (cb) {
            $('div.check_row')
                .addClass('animated fadeIn')
                .callback(cb);
        },

        animateBtnPlay: function (cb) {
            $('.btn_holder')
                .css({display: 'block'})
                .addClass('animated zoomIn')
                .callback(cb)
        },

        animateEquip: function (cb) {
            $('.char_holder .equip')
                .addClass('animated equipFade');
        }
    };
});

