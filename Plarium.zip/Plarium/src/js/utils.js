define(['jQuery'], function ($) {
    $.fn.callback = function (callback) {
        return this.one('webkitAnimationEnd mozAnimationEnd MSAnimationEnd oanimationend animationend', function (e) {
            //required for proper work of async
            if (typeof callback === 'function') callback(null, e);
        });
    };

    return {};
});